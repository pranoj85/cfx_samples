package tk.learntosuccess;

public class OperationsImpl implements Operations {

	@Override
	public int add(int a, int b) {
		return a+b;
	}

}
